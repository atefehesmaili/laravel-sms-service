
use App\Http\Controllers\SmsController;

Route::get('/admin/sms/form', [SmsController::class, 'showForm'])->name('sms.form');
Route::post('/admin/sms/send', [SmsController::class, 'sendBulk'])->name('sms.send.bulk');
Route::get('/test-sms', [SmsController::class, 'sendSms']);
