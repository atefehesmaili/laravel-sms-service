
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SmsService;

class SmsController extends Controller
{
    public function sendSms()
    {
        try {
            $sms = new SmsService();
            $result = $sms->sendSms('09*********', 'پیام تستی');
            return response()->json($result);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

    public function showForm()
    {
        return view('admin.sms.form');
    }

    public function sendBulk(Request $request, SmsService $smsService)
    {
        $request->validate([
            'message' => 'required|string',
            'phones' => 'required|string',
        ]);

        $phonesRaw = explode(',', $request->phones);
        $message = $request->message;

        $validPhones = [];
        foreach ($phonesRaw as $phone) {
            $clean = trim($phone);
            if (preg_match('/^09\d{9}$/', $clean)) {
                $validPhones[] = $clean;
            }
        }

        if (empty($validPhones)) {
            return back()->with('error', 'هیچ شماره معتبری وارد نشده است.');
        }

        foreach ($validPhones as $phone) {
            $smsService->send($phone, $message);
        }

        return back()->with('success', 'پیامک‌ها با موفقیت ارسال شدند.');
    }
}
