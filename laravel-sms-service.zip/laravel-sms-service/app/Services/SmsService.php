
<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class SmsService
{
    protected $token;

    public function __construct()
    {
        $this->getToken();
    }

    private function getToken()
    {
        $apiKey = env('SMSIR_API_KEY');
        $secretKey = env('SMSIR_SECRET_KEY');

        $response = Http::post('https://ws.sms.ir/api/Token', [
            'UserApiKey' => $apiKey,
            'SecretKey' => $secretKey,
        ]);

        if ($response->successful() && $response->json('TokenKey')) {
            $this->token = $response->json('TokenKey');
        } else {
            throw new \Exception('دریافت توکن پیامک با خطا مواجه شد.');
        }
    }

    public function sendSms($mobile, $message)
    {
        $lineNumber = env('SMSIR_LINE_NUMBER');

        $response = Http::withHeaders([
            'x-sms-ir-secure-token' => $this->token
        ])->post('https://ws.sms.ir/api/MessageSend', [
            'Messages' => [$message],
            'MobileNumbers' => [$mobile],
            'LineNumber' => $lineNumber,
            'SendDateTime' => '',
            'CanContinueInCaseOfError' => false
        ]);

        return $response->json();
    }

    public function send($mobile, $message)
    {
        $apiKey = env('SMSIR_API_KEY');
        $secretKey = env('SMSIR_SECRET_KEY');
        $lineNumber = env('SMSIR_LINE_NUMBER');

        $tokenResponse = Http::post('https://ws.sms.ir/api/Token', [
            'UserApiKey' => $apiKey,
            'SecretKey' => $secretKey,
        ]);

        if (!$tokenResponse->successful() || !$tokenResponse->json('TokenKey')) {
            return false;
        }

        $token = $tokenResponse->json('TokenKey');

        Http::withHeaders([
            'x-sms-ir-secure-token' => $token
        ])->post('https://ws.sms.ir/api/MessageSend', [
            'Messages' => [$message],
            'MobileNumbers' => [$mobile],
            'LineNumber' => $lineNumber,
            'SendDateTime' => '',
            'CanContinueInCaseOfError' => false
        ]);

        return true;
    }
}
