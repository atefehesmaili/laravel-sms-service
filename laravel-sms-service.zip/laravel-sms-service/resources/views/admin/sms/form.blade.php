
@extends('layouts.app')

@section('content')
<div class="container">
    <h2>ارسال پیامک گروهی</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @elseif(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    <form method="POST" action="{{ route('sms.send.bulk') }}">
        @csrf
        <div class="mb-3">
            <label>شماره‌ها (با کاما جدا کنید)</label>
            <textarea name="phones" class="form-control" rows="3">{{ old('phones') }}</textarea>
        </div>
        <div class="mb-3">
            <label>متن پیام</label>
            <textarea name="message" class="form-control" rows="3">{{ old('message') }}</textarea>
        </div>
        <button type="submit" class="btn btn-primary">ارسال پیامک</button>
    </form>
</div>
@endsection
